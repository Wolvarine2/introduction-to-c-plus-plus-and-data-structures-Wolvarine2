package com.thriftyApp;

public class Utils {
	
	//Email Validation pattern
	public static final String regEx = "\\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}\\b";

	//Fragments Tags
	public static final String Login_Fragment = "Login_Fragment";
	public static final String SignUp_Fragment = "SignUp_Fragment";
	public static String userId = "0";
	public static String budget = "0";
	public static String userName = "";
	public static int expense = 0;
	public static int income= 0;
	public static int pdfNumber = 1;
}
